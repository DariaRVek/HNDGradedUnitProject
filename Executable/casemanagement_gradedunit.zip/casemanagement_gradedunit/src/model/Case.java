package model;

/**
 * Class Case to store details of a Case.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class Case {
	
	//Instance fields
	private String title;
	private CaseType type;
	private String description;
	private final Employee SOLICITOR;
	private static int caseCount = 0;
	private final String CASE_REF_NUM;
	
	/**
	 * Constructor method to create a new Case.
	 * @param title - the title of the Case.
	 * @param type - the type of the Case.
	 * @param description - the description of the Case.
	 * @param emp - the Solicitor responsible for this Case.
	 */
	public Case(String title, CaseType type, String description, Employee emp) {
		this.title = title;
		this.type = type;
		this.description = description;
		this.SOLICITOR = emp;
		caseCount++;
		this.CASE_REF_NUM = generateRefNum();
	} //end constructor method
	
	/**
	 * Method to generate a unique reference number for this Case.
	 * Makes use of counter field pre-incremented in constructor method.
	 * Formats the reference to contain 3 digits, a dash, and Case type.
	 * @return the formatted Case Reference Number.
	 */
	private String generateRefNum() {
		return String.format("%03d", caseCount) + "-" + this.type.toString();
	} //end method genRefNum
	
	/**
	 * Method to access this Case's CASE_REF_NUM.
	 * @return CASE_REF_NUM
	 */
	public String getCASE_REF_NUM() {
		return CASE_REF_NUM;
	} //end method getCASE_REF_NUM
	
	/**
	 * Method to access this Case's description.
	 * @return description
	 */
	public String getDescription() {
		return description;
	} //end method getDescription
	
	/**
	 * Method to access this Case's responsible Solicitor.
	 * @return SOLICITOR
	 */
	public Employee getSOLICITOR() {
		return SOLICITOR;
	} //end method getSOLICITOR
	
	/**
	 * Method to access this Case's title.
	 * @return title
	 */
	public String getTitle() {
		return title;
	} //end method getTitle
	
	/**
	 * Method to access this Case's type.
	 * @return type
	 */
	public CaseType getType() {
		return type;
	} //end method getType
	
	/**
	 * Method to create a String comprised of this Case's details.
	 * @return this Case's details.
	 */
	@Override
	public String toString() {
		return "\nCase Reference Number : " + CASE_REF_NUM 
				+ "\nCase Title : " + title
				+ "\nCase Type : " + type 
				+ "\nSolicitor Name : " + SOLICITOR.getFullName()
				+ "\nCase Description : " + description;
	} //end method toString
} //end class Case
