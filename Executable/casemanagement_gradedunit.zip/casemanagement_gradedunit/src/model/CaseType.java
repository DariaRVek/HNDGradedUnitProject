package model;

/**
 * Enum CaseType to define potential values of Case Type.
 * Values in enum are also used to populate Enquiry Type field in Add New Case interface.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public enum CaseType {
	
	CRI,
	IMM,
	PIN;

} //end enum CaseType
