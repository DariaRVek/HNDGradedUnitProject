package model;

import java.text.ParseException;

/**
 * Class Client to store details of a Client.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class Client extends Person {

	//Instance fields
	private final Case CASE;
	private final int CLIENT_ID;
	private static int clientCount = 0;
	
	/**
	 * Constructor method to create Client object.
	 * @param fName - this Client's first name.
	 * @param lName - this Client's last name.
	 * @param dob - - this Client's date of birth.
	 * @param addressLOne - this Client's address line one.
	 * @param addressLTwo - this Client's address line two.
	 * @param postcode - this Client's postcode.
	 * @param phoneNum - this Client's phone number.
	 * @param legalCase - the Case linked to this Client.
	 * @throws ParseException - thrown if date of birth cannot be parsed.
	 */
	public Client(String fName, String lName, String dob, String addressLOne, String addressLTwo,
			String postcode, String phoneNum, Case legalCase) throws ParseException {
		super(fName, lName, dob, addressLOne, addressLTwo, postcode, phoneNum);
		CLIENT_ID = ++clientCount;
		this.CASE = legalCase;
	} //end constructor method
	
	/**
	 * Method to access this Client's Case.
	 * @return CASE
	 */
	public Case getCASE() {
		return CASE;
	} //end method getCASE
	
	/**
	 * Method to access this Client's ID.
	 * @return CLIENT_ID
	 */
	public int getCLIENT_ID() {
		return CLIENT_ID;
	} //end method getCLIENT_ID
	
	/**
	 * Method to create a String comprised of this Client's details.
	 * @return this Client's details
	 */
	@Override
	public String toString() {
		return "Client\n" + super.toString() 
		+ "\nClient ID : " + CLIENT_ID;
	} //end method toString
} //end class Client
