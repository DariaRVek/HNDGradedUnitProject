package model;

import java.text.ParseException;

/**
 * Class Employee to store details of an Employee.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class Employee extends Person {
	
	//Instance fields
	private final int STAFFID;
	private static int staffCount = 0;
		
	/**
	 * Constructor method to create an Employee object.
	 * @param fName - the Employee's first name.
	 * @param lName - the Employee's last name.
	 * @param dob - the Employee's date of birth.
	 * @param addressLOne - the Employee's first line of address.
	 * @param addressLTwo - the Employee's second line of address.
	 * @param postcode - the Employee's postcode.
	 * @param phoneNum - the Employee's phone number.
	 * @throws ParseException - thrown if dob cannot be parsed.
	 */
	public Employee(String fName, String lName, String dob, String addressLOne, String addressLTwo,
			String postcode, String phoneNum) throws ParseException {
		super(fName, lName, dob, addressLOne, addressLTwo, postcode, phoneNum);
		this.STAFFID = ++staffCount;
	} //end constructor method

	/**
	 * Method to access this Employee's staff ID number.
	 * @return the STAFFID
	 */
	public int getSTAFFID() {
		return STAFFID;
	} //end method getSTAFFID
	
	/**
	 * Method to create a String comprised of this Employee's details.
	 * @return this Employee's details.
	 */
	@Override
	public String toString() {
		return "Solicitor\n" + super.toString()
			+ "Solicitor ID : " + STAFFID;
	} //end method toString
} //end class Employee