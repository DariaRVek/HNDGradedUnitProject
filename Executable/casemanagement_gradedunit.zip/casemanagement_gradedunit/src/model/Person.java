package model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Abstract superclass Person to store details common to Employee and Client.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public abstract class Person {
	
	//Instance fields
	protected String firstName;
	protected String lastName;
	protected Date dob;
	protected String addressLineOne;
	protected String addressLineTwo;
	protected String postcode;
	protected String phoneNum;
	protected DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	
	/**
	 * Constructor method to set values of instance fields.
	 * @param firstName - the first name of Employee/Client.
	 * @param lastName - the last name of Employee/Client.
	 * @param dob - the date of birth of Employee/Client.
	 * @param addressLOne - the first line of address of Employee/Client.
	 * @param addressLTwo - the second line of address of Employee/Client.
	 * @param postcode - the postcode of Employee/Client.
	 * @param phoneNum - the phone number of Employee/Client.
	 * @throws ParseException - thrown if dob cannot be parsed.
	 */
	public Person(String firstName, String lastName, String dob, String addressLOne, String addressLTwo,
			String postcode, String phoneNum) throws ParseException {
		this.firstName = firstName;
		this.lastName = lastName;
		this.dob = dateFormat.parse(dob);
		this.addressLineOne = addressLOne;
		this.addressLineTwo = addressLTwo;
		this.postcode = postcode.toUpperCase();
		this.phoneNum = phoneNum;
	} //end super constructor method
	
	/**
	 * Method to access this Person's address line one.
	 * @return addressLineOne
	 */
	public String getAddressLineOne() {
		return addressLineOne;
	} //end method getAddressLineOne

	/**
	 * Method to access this Person's address line two.
	 * @return addressLineTwo
	 */
	public String getAddressLineTwo() {
		return addressLineTwo;
	} //end method getAddressLineTwo
	
	/**
	 * Method to access this Person's date of birth.
	 * @return dob
	 */
    public Date getDOB() {
    	return dob;
    } //end method getDOB
    
	/**
	 * Method to access this Person's first name.
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	} //end method getFirstName
	
	/**
	 * Method to access this Person's full name.
	 * @return the first name concatenated to last name
	 */
	public String getFullName() {
		return firstName + " " + lastName;
	} //end method getFullName
	
	/**
	 * Method to access this Person's last name.
	 * @return lastName
	 */
    public String getLastName() {
        return lastName;
    }//end method getFirstName 
    
	/**
	 * Method to access this Person's phone number.
	 * @return phoneNum
	 */
	public String getPhoneNum() {
		return phoneNum;
	} //end method getPhoneNum

	/**
	 * Method to access this Person's postcode.
	 * @return postcode
	 */
	public String getPostcode() {
		return postcode;
	} //end method getPostcode

	/**
	 * Method to create a String comprised of this Person's details.
	 * @return this Person's details.
	 */
	@Override
	public String toString() {
		return "First Name : " + firstName 
			+ "\nLast Name : " + lastName 
			+ "\nDob : " + dob
			+ "\nAddress : " + addressLineOne + ", " + addressLineTwo
			+ "\nPostcode : " + postcode
			+ "\nPhone Number : " + phoneNum;
	} //end method toString
} //end class Person