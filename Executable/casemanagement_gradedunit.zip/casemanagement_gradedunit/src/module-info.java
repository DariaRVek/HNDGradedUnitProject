/**
 * 
 */
/**
 * @author daria
 *
 */
module casemanagement_gradedunit {
	requires java.desktop;
}