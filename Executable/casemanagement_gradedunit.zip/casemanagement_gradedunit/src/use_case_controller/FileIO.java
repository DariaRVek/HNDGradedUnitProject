package use_case_controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/**
 * Class FileIO responsible for reading/writing files.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class FileIO {
	
	/**
	 * Method to check if the required Paths and Files exist in user's storage.
	 * @param dirPath the path of the directory structure required to maintain data
	 * @param filePath the path to the files required to maintain data
	 * @return absPath the path to the files
	 */
	public Path checkFiles(Path dirPath, Path filePath) {
		Path absPath = dirPath.resolve(filePath);
		try {
			if(Files.notExists(dirPath))
				Files.createDirectories(dirPath); //if path doesn't exist create the directory structure
			//endif
			if(Files.notExists(absPath))
				Files.createFile(absPath); //if the file doesn't exist create the file
		}//end try
		catch (IOException x) {
			System.err.println(x);
			return null;
		}//end catch
		return absPath;
	} //end method checkFiles
	
	/**
	 * Method to control routine of creating file paths if they don't exist.
	 * Invoked when program is launched to allow for data persistence.
	 */
	public void createPaths() {
		Path p = Paths.get("C:/McRae&DickCaseManagementSystem"); //the directory
		Path usersfilePath = Paths.get("Users.txt"); //the text file for login data
		Path users;
		users = checkFiles(p, usersfilePath);
	} //end method createPaths
	
	/**
	 * Method to read in login credentials from text file.
	 * @return map the HashMap containing login credentials.
	 */
	public HashMap<String, String> readFromFile() {
		HashMap<String, String> map = new HashMap<String, String>();
		String line = ""; //stores each line read from file
		//Path object to hold absolute file path returned from static method get() from Path class
		//This static call returns an instance of an absolute file path
		Path path = Paths.get("C:/McRae&DickCaseManagementSystem/Users.txt");
		try {
			//Use Files class to return a BufferedReader object from path value supplied
			//Character set is defined
			BufferedReader fileInput = Files.newBufferedReader(path, Charset.forName("ISO-8859-1"));
			line = fileInput.readLine();
			while(line != null) {
				//split the line by the comma
				String[] data = line.split(", ");
				//Key is username
				String username = data[0].trim();
				String pw = data[1].trim();
				//put Key and Value into the map
				if(!username.equals("") && !pw.equals(""))
					map.put(username, pw);
					line = fileInput.readLine();
			} //end while
			fileInput.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found.");
		} //end catch
		catch(EOFException eofe) {
			System.out.println("No more lines to read.");
		} //end catch
		catch(IOException ioe) {
			System.out.println("Error reading file.");
		} //end catch
		return map;
	} //end method readFromFile
	
	/**
	 * Method to write updated login credentials to file.
	 * @param logins the Map to be written to file.
	 */
	public void writeToFile(HashMap<String, String> logins) {
		File file = new File("C:/McRae&DickCaseManagementSystem/Users.txt");
		BufferedWriter bf = null;
		try {
			bf = new BufferedWriter(new FileWriter(file));
			for(Map.Entry<String, String> entry : logins.entrySet()) {
				bf.write(entry.getKey() + ", " + entry.getValue()); //write the Key and Value to file separated with comma
				bf.newLine(); //take a new line
			} //endfor
			bf.flush();
		} //end try
		catch(IOException e) {
			e.printStackTrace();
		} //end catch
		finally {
			try {
				bf.close();
			} //end try
			catch(Exception e) {
				System.out.println("Something went wrong.");
			} //end catch
		} //end finally
	} //end method writeToFile
} //end class FileIO