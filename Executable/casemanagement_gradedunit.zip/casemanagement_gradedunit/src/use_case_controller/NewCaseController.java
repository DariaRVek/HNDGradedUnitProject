package use_case_controller;

import java.awt.Color;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import model.Case;
import model.CaseType;
import model.Client;
import model.Employee;
import view.CommonElements;

/**
 * Class NewCaseController to manage various validation and control flows of managing Caseload.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class NewCaseController {
	
	//Error messages to be displayed - taken from Solution Planning report
	public String error2 = "Field cannot be blank.";
	private String error4 = "Case title must be in format "
							+ "[client surname] v [opponent] using "
							+ "alphabetical characters only.";
	private String error5 = "Name field cannot contain numbers.";
	private String error6 = "DOB invalid. DOB must be entered in format DD/MM/YYYY.";
	private String error7 = "DOB must contain valid numeric values.";
	private String error8 = "Postcode invalid.";
	private String error9 = "Phone number invalid. Must contain digits only "
							+ "and cannot contain whitespace or special characters.";
	public String error11 = "Invalid fields. Please review.";
	
	private CommonElements commonElements = new CommonElements(); //to access common elements
	
	//Instance field to hold number of invalid fields, if any.
	//Used to control if a case is added to List or not.
	private int invalidFields = 0;
	
	
	/**
	 * Method to add a Case to List.
	 * @param position the given Solicitor for this Case.
	 * @param emps the List of Employees to be searched.
	 * @param empName the name of the Solicitor to search for.
	 * @param cases the List of Cases to be added to.
	 * @param title the title of the new Case.
	 * @param type the type of the new Case.
	 * @param desc the description of the new Case.
	 * @param clients the List of Clients to be added to.
	 * @param fName the Client's first name.
	 * @param lName the Client's last name.
	 * @param dob the Client's date of birth.
	 * @param address1 the Client's address first line.
	 * @param address2 the Client's address second line.
	 * @param postcode the Client's postcode.
	 * @param phoneNum the Client's phone number.
	 * @throws ParseException thrown if the DOB field cannot be parsed.
	 */
	private void addCase(int position, ArrayList<Employee> emps, String empName, 
			ArrayList<Case> cases, String title, CaseType type, String desc, 
			ArrayList<Client> clients, String fName, String lName,
			String dob, String address1, String address2, String postcode,
			String phoneNum) throws ParseException {
		position = findSolicitor(emps, empName); //find the Solicitor
		cases.add(new Case(title, type, desc, emps.get(position)));	
		addClient(clients, fName, lName, dob, address1, address2, postcode, phoneNum, cases);
		JOptionPane.showMessageDialog(null, "Case successfully added\nRef Num: " + clients.get(clients.size()-1).getCASE().getCASE_REF_NUM());
	} //end method addCase
	
	
	/**
	 * Method to add new Client to Client List.
	 * @param clients the List of Clients to be added to.
	 * @param fName the Client's first name.
	 * @param lName the Client's last name.
	 * @param dob the Client's date of birth.
	 * @param address1 the Client's address first line.
	 * @param address2 the Client's address second line.
	 * @param postcode the Client's postcode.
	 * @param phoneNum the Client's phone number.
	 * @param cases the List the Client's Case is contained in.
	 * @throws ParseException thrown if the DOB field cannot be parsed.
	 */
	private void addClient(ArrayList<Client> clients, String fName, String lName,
			String dob, String address1, String address2, String postcode,
			String phoneNum, ArrayList<Case> cases) throws ParseException {
		clients.add(new Client(fName, lName, dob, address1, address2, postcode, phoneNum, cases.get(cases.size()-1)));
	} //end method addClient
	
	
	/**
	 * Method to control routine of adding a new and valid Case to the List.
	 * @param caseTitleTxtField Case Title input.
	 * @param caseTypeCBox Case Type selection.
	 * @param caseDescTxtField Case Description input.
	 * @param solCBox Solicitor selection.
	 * @param fNameTxtField Client first name input.
	 * @param lNameTxtField Client last name input.
	 * @param dobTxtField Client date of birth input.
	 * @param addressFLineTxtField Client address line 1 input.
	 * @param addressSLineTxtField Client address line 2 input.
	 * @param postcodeTxtField Client postcode input.
	 * @param phoneTxtField Client phone number input.
	 * @param employees the List of employees from which a responsible Solicitor is selected and assigned to a Case.
	 * @param clients the List to add a Client object to.
	 * @param cases the List to add the new Case object to.
	 * @return true if Case is added to List; false otherwise.
	 * @throws ParseException thrown if the DOB field cannot be parsed.
	 */
	public boolean addNewCase(JTextField caseTitleTxtField, JComboBox caseTypeCBox, JTextArea caseDescTxtField, JComboBox solCBox,
			JTextField fNameTxtField, JTextField lNameTxtField, JTextField dobTxtField,
			JTextField addressFLineTxtField, JTextField addressSLineTxtField,
			JTextField postcodeTxtField, JTextField phoneTxtField,
			ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) throws ParseException {
		//Variables for a Case object
		String title = getValidCaseTitle(caseTitleTxtField);
		CaseType type = (CaseType) caseTypeCBox.getSelectedItem();
		String desc=caseDescTxtField.getText();
		String solicitor = (String) solCBox.getSelectedItem();
		int position = 0;
		//Variables for a Client object
		String fName = getValidFName(fNameTxtField);
		String lName = getValidLName(lNameTxtField);
		String dob = getValidDob(dobTxtField);
		String address1="", address2="";
		if(validateAddress(addressFLineTxtField.getText(), addressSLineTxtField.getText())) {
			address1 = addressFLineTxtField.getText();
			address2 = addressSLineTxtField.getText();
		} else {
			invalidFields = invalidFields+2;
			commonElements.showError(error11, "Invalid Address");
			commonElements.outlineRed(addressFLineTxtField);
			commonElements.outlineRed(addressSLineTxtField);
		} //end if else
		String postcode = getValidPostcode(postcodeTxtField);
		String phoneNum = getValidPhone(phoneTxtField);
		
		if(invalidFields == 0) { //data is ready for Controller to construct new object
			addCase(position, employees, solicitor, cases, 
								title, type, desc, clients, fName, lName, 
								dob, address1, address2, postcode, phoneNum);
			return true;
		} else {
			invalidFields = 0; //reset invalidFields ready for next attempt
			return false;
		} //end if else
	} //end method addNewCase
	

	/**
	 * Method to check for empty fields
	 * @param caseTitleTxtField Case Title input
	 * @param caseDescTxtField Case Description input
	 * @param fNameTxtField Client first name input
	 * @param lNameTxtField Client last name input
	 * @param dobTxtField Client date of birth input
	 * @param addressFLineTxtField Client address first line input
	 * @param addressSLineTxtField Client address second line input
	 * @param postcodeTxtField Client postcode input
	 * @param phoneTxtField Client phone number input
	 * @return emptyFields the number of empty fields
	 */
	public int checkEmpty(JTextField caseTitleTxtField, JTextArea caseDescTxtField, JTextField fNameTxtField, 
			JTextField lNameTxtField, JTextField dobTxtField, JTextField addressFLineTxtField,
			JTextField addressSLineTxtField, JTextField postcodeTxtField, JTextField phoneTxtField) {
		int numEmptyFields = 0;
		if(caseTitleTxtField.getText().equals("Enter case title") || isEmpty(caseTitleTxtField.getText())) {
			commonElements.outlineRed(caseTitleTxtField);
			numEmptyFields++;
		}
		if(caseDescTxtField.getText().equals("Enter description here") || isEmpty(caseDescTxtField.getText())) {
			caseDescTxtField.setBorder(new LineBorder(Color.RED, 2));
			numEmptyFields++;
		}
		if(fNameTxtField.getText().equals("Enter first name") || isEmpty(fNameTxtField.getText())) {
			commonElements.outlineRed(fNameTxtField);
			numEmptyFields++;
		}
		if(lNameTxtField.getText().equals("Enter last name") || isEmpty(lNameTxtField.getText())) {
			commonElements.outlineRed(lNameTxtField);
			numEmptyFields++;
		}
		if(dobTxtField.getText().equals("DD/MM/YYYY") || isEmpty(dobTxtField.getText())) {
			commonElements.outlineRed(dobTxtField);
			numEmptyFields++;
		}
		if(addressFLineTxtField.getText().equals("Address line 1") || isEmpty(addressFLineTxtField.getText())) {
			commonElements.outlineRed(addressFLineTxtField);
			numEmptyFields++;
		}
		if(addressSLineTxtField.getText().equals("Address line 2") || isEmpty(addressSLineTxtField.getText())) {
			commonElements.outlineRed(addressSLineTxtField);
			numEmptyFields++;
		}
		if(postcodeTxtField.getText().equals("Enter postcode") || isEmpty(postcodeTxtField.getText())) {
			commonElements.outlineRed(postcodeTxtField);
			numEmptyFields++;
		}
		if(phoneTxtField.getText().equals("Enter phone no.") || isEmpty(phoneTxtField.getText())) {
			commonElements.outlineRed(phoneTxtField);
			numEmptyFields++;
		}
		return numEmptyFields;
	} //end method checkEmpty
	
	
	/**
	 * Method to find element in List.
	 * @param employees the List to be searched.
	 * @param solicitor the name selected by the user.
	 * @return position the position at which selected element is found in List.
	 */
	private int findSolicitor(ArrayList<Employee> employees, String solicitor) {
		int position = 0;
		ListIterator<Employee> lIterator = employees.listIterator();
		while(lIterator.hasNext()) 
			if(lIterator.next().getFullName().equals(solicitor)) 
				position = lIterator.previousIndex();
		return position;
	} //end method findSolicitor
	
	
	/**
	 * Method to retrieve all Solicitor names.
	 * Names stored in one-dimensional array for use in JComboBox.
	 * @param employees the List of Employee objects to be iterated over.
	 * @return empNames a 1D array of Employee object names.
	 */
	public String[] getNames(ArrayList<Employee> employees) {
		String[] empNames = new String [employees.size()];
		for(int i = 0; i < empNames.length; i++) {
			empNames[i] = employees.get(i).getFullName();
		} //endfor
		return empNames;
	} //end method getNames
	
	
	/**
	 * Method to send Case Title data for validation.
	 * Called in addNewCase method.
	 * If input is invalid, increments invalidFields by 1.
	 * @return title the valid Case Title
	 */
	private String getValidCaseTitle(JTextField caseTitleTxtField) {
		String title = "";
		if(validateCaseTitle(caseTitleTxtField.getText())) {
			title = caseTitleTxtField.getText();
		} else {
			invalidFields++;
			commonElements.showError(error4, "Invalid");
			commonElements.outlineRed(caseTitleTxtField);
		} //end if else
		return title;
	} //end method getCase
	
	
	/**
	 * Method to get a valid date of birth value.
	 * Checks date in valid format and contains valid value.
	 * @return date a valid date of birth.
	 */
	private String getValidDob(JTextField dobTxtField) {
		String dob="";
		if(validateDateFormat(dobTxtField.getText())) { //if the format is valid
			if(validateDate(dobTxtField.getText())) { //if the value is valid
				dob = dobTxtField.getText();
			} else { //invalid date value
				invalidFields++;
				commonElements.showError(error7, "DOB Invalid");
				commonElements.outlineRed(dobTxtField);
			} //end if else
		} else { //invalid date format
			invalidFields++;
			commonElements.showError(error6, "DOB Format Invalid");
			commonElements.outlineRed(dobTxtField);
		} //end if else
		return dob;
	} //end method getValidDob
	
	
	/**
	 * Method to receive valid first name value
	 * @return fName a valid first name
	 */
	private String getValidFName(JTextField fNameTxtField) {
		String fName="";
		if(validateName(fNameTxtField.getText())) {
			fName = fNameTxtField.getText();
		} else {
			invalidFields++;
			commonElements.showError(error5, "Invalid Name");
			commonElements.outlineRed(fNameTxtField);
		} //end if else
		return fName;
	} //end method getValidFName
	
	
	/**
	 * Method to receive valid last name value
	 * @return fName (String) a valid last name
	 */
	private String getValidLName(JTextField lNameTxtField) {
		String lName="";
		if(validateName(lNameTxtField.getText())) {
			lName = lNameTxtField.getText();
		} else {
			invalidFields++;
			commonElements.showError(error5, "Invalid Name");
			commonElements.outlineRed(lNameTxtField);
		} //end if else
		return lName;
	} //end method getValidLName
	
	
	/**
	 * Method to receive a valid phone number value
	 * @param phoneNumTxtField Client phone number input
	 * @return phoneNum (String) a valid phone number value
	 */
	private String getValidPhone(JTextField phoneNumTxtField) {
		String phoneNum = "";
		if(validatePhoneNum(phoneNumTxtField.getText())) {
			phoneNum = phoneNumTxtField.getText();
		} else {
			invalidFields++;
			commonElements.showError(error9, "Invalid Phone Number");
			commonElements.outlineRed(phoneNumTxtField);
		} //end if else
		return phoneNum;
	} //end method getValidPhone
	
	
	/**
	 * Method to receive a valid postcode value
	 * @param postcodeTxtField Client postcode input
	 * @return postcode a valid postcode value
	 */
	private String getValidPostcode(JTextField postcodeTxtField) {
		String postcode = "";
		if(validatePostcode(postcodeTxtField.getText())) {
			postcode = postcodeTxtField.getText();
			//make sure postcode in correct format ready for storage
			if(!postcode.contains(" ")) {
				// 1. split the postcode
				String outwardCode = postcode.substring(0, postcode.length()-3).toUpperCase();
				String inwardCode = postcode.substring(postcode.length()-3).toUpperCase();
				// 2. update postcode to include space
				postcode = outwardCode + " " + inwardCode;
			} //endif
		} else {
			invalidFields++;
			commonElements.showError(error8, "Invalid Postcode");
			commonElements.outlineRed(postcodeTxtField);
		} //end if else
		return postcode;
	} //end method getValidPostcode
	
	
	/**
	 * Method to check for an empty field.
	 * @param text the String value to be checked.
	 * @return true if String is empty; otherwise false.
	 */
	private boolean isEmpty(String text) {
		return (text.equals("") || text==null) ? true : false;
	}  //end method isEmpty

	
	/**
	 * Method to validate an address against regular expression.
	 * @param address1 the String value that makes up part of an address.
	 * @param address2 the String value that completes the address.
	 * @return true if both Strings conform to regex; false otherwise.
	 */
	private boolean validateAddress(String address1, String address2) {
		return (address1.matches("^[\\n\\r\\x20-\\x7E]+$") && address2.matches("^[\\n\\r\\x20-\\x7E]+$")) ? true : false;
	} //end method valid

	
	/**
	 * Method to validate a Case title against a regular expression.
	 * @param title the String value to be validated.
	 * @return true if String matches the regular expression; false otherwise.
	 */
	private boolean validateCaseTitle(String title) {
		return title.matches("^[A-Za-z ]+ v [A-Za-z ]+$");
	} //end method validateCaseTitle
	
	
	/**
	 * Method to make use of Pattern and Matcher classes to validate a date.
	 * @param dob the date to be validated.
	 * @return	true if date value is valid; false otherwise.
	 */
	private boolean validateDate(String dob) {
		boolean valid = false;
		Pattern datePattern = Pattern.compile("(0[1-9]|[12][0-9]|[3][01])/(0[1-9]|1[012])/(\\d{4})");
		Matcher dateMatcher = datePattern.matcher(dob);
		if(dateMatcher.matches()) { //if the format is valid
			String year = dateMatcher.group(3); //segment group 3 to access YYYY
			if(year.charAt(0) == '1' || year.charAt(0) == '2') { //check first digit is 1 or 2
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				dateFormat.setLenient(false);  //dob must match SimpleDate pattern exactly
				try {
					dateFormat.parse(dob); //parse the String value
					valid = true; //all validation checks have been passed, the data is acceptable
				} //end try 
				catch (ParseException p) {
					commonElements.showError(error7, "Invalid"); //invalid values
				} //end try catch
			} //endif
		} //else the format is invalid 
		else
			commonElements.showError(error6, "Invalid"); //invalid format
		//endif
		return valid;
	} //end method validateDate
	
	
	/**
	 * Method to validate the format of a date.
	 * @param dob the String value to evaluate.
	 * @return true if date is in acceptable format; otherwise false.
	 */
	private boolean validateDateFormat(String dob) {
		return dob.matches("(0[1-9]|[12][0-9]|[3][01])/(0[1-9]|1[012])/(\\d{4})");
	} //end method validateDateFormat

	
	/**
	 * Method to validate a name against regular expression.
	 * @param name the name to be validated.
	 * @return true if name is acceptable; false otherwise.
	 */
	private boolean validateName(String name) {
		return name.matches("^[A-Z][a-zA-Z]{1,25}$");
	} //end method validateName
	
	
	/**
	 * Method to validate a UK phone number against regular expression.
	 * @param phoneNum the phone number to be validated.
	 * @return true if phone number is acceptable; false otherwise.
	 */
	private boolean validatePhoneNum(String phoneNum) {
		return (phoneNum.matches("^0[0-9]{10}") || phoneNum.replaceAll(" ", "").matches("^0[0-9]{10}")) ? true : false;
	} //end method validatePhoneNum
	
	
	/**
	 * Method to validate a UK postcode against regular expression.
	 * Regular expression abstracted from GOV.UK.
	 * Can be found at the following address:
	 * https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/488478/Bulk_Data_Transfer_-_additional_validation_valid_from_12_November_2015.pdf
	 * @param postcode the postcode to be validated.
	 * @return true if postcode is acceptable; false otherwise.
	 */
	private boolean validatePostcode(String postcode) {
		//make sure postcode in correct format ready for validating
		if(!postcode.contains(" ")) {
			// 1. split the postcode
			String outwardCode = postcode.substring(0, postcode.length()-3);
			String inwardCode = postcode.substring(postcode.length()-3);
			// 2. update postcode to include space
			postcode = outwardCode + " " + inwardCode;
		} //endif
		if (postcode.matches("^([Gg][Ii][Rr] 0[Aa]{2})|((([A-Za-z][0-9]{1,2})|(([A-Za-z][A-Ha-hJ-Yj-y][0-9]{1,2})|(([A-Za-z][0-9][A-Za-z])|([A-Za-z][A-Ha-hJ-Yj-y][0-9]?[A-Za-z])))) [0-9][A-Za-z]{2})$"))
			return true;
		return false;
	}// end method validatePostcode
} //end class NewCaseController