package view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.Case;
import model.CaseType;
import model.Client;
import model.Employee;
import use_case_controller.NewCaseController;

/**
 * Class AddCaseInterface to construct interface for user to add a new Case.
 * Interacts with NewCaseController to ensure data input is valid.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class AddCaseInterface extends JFrame {

	private static final long serialVersionUID = 1L;
	//Instance fields for AddCaseInterface
	private JPanel contentPane;
	private JTextField fNameTxtField;
	private JTextField lNameTxtField;
	private JTextField dobTxtField;
	private JTextField addressFirstLineTxtField;
	private JTextField addressSecondLineTxtField;
	private JTextField postcodeTxtField;
	private JTextField phoneNumTxtField;
	private JTextField caseTitleTxtField;
	private JTextArea caseDescriptionTxtArea;
	private JComboBox caseTypeComboBox;
	private JComboBox enqTypeComboBox;
	private JComboBox solComboBox;
	private JButton confirmCaseButton;
	private CommonElements commonElements = new CommonElements(); //to access common elements
	private NewCaseController controller = new NewCaseController(); //for Controller interaction
	
	
	/**
	 * Constructor method that calls createNewCaseForm() method.
	 * @param employees the List of Employees to be searched.
	 * @param clients the List of Clients to be added to.
	 * @param cases the List of Cases to be added to.
	 */
	public AddCaseInterface(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) {
		createNewCaseForm(employees, clients, cases);
	} //end constructor method
	
	
	/**
	 * Method to construct the GUI.
	 * @param employees the List of Employees to be searched.
	 * @param clients the List of Clients to be added to.
	 * @param cases the List of Cases to be added to.
	 */
	private void createNewCaseForm(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1100, 710);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//add the navigation menu to the GUI
		commonElements.constructNavMenu(contentPane, employees, clients, cases);
		
		JLabel caseFormLabel = new JLabel("Case Details");
		caseFormLabel.setFont(new Font("Verdana", Font.BOLD, 16));
		caseFormLabel.setForeground(Color.WHITE);
		caseFormLabel.setBounds(223, 130, 126, 22);
		contentPane.add(caseFormLabel);
		
		JLabel clientFormLabel = new JLabel("Client Details");
		clientFormLabel.setForeground(Color.WHITE);
		clientFormLabel.setFont(new Font("Verdana", Font.BOLD, 16));
		clientFormLabel.setBounds(502, 130, 126, 22);
		contentPane.add(clientFormLabel);
		
		JLabel solicitorFormLabel = new JLabel("Solicitor Details");
		solicitorFormLabel.setForeground(Color.WHITE);
		solicitorFormLabel.setFont(new Font("Verdana", Font.BOLD, 16));
		solicitorFormLabel.setBounds(835, 130, 155, 22);
		contentPane.add(solicitorFormLabel);
		
		caseTypeComboBox = new JComboBox();
		caseTypeComboBox.setForeground(Color.BLACK);
		caseTypeComboBox.setFont(new Font("Verdana", Font.ITALIC, 10));
		caseTypeComboBox.setModel(new DefaultComboBoxModel(CaseType.values()));
		caseTypeComboBox.setBounds(299, 163, 140, 33);
		caseTypeComboBox.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				caseTypeComboBoxActionPerformed(event);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to caseTypeComboBoxActionPerformed ActionListener
		contentPane.add(caseTypeComboBox);
		
		JLabel caseTypeLabel = new JLabel("Case Type:");
		caseTypeLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		caseTypeLabel.setForeground(Color.WHITE);
		caseTypeLabel.setBounds(223, 174, 73, 14);
		contentPane.add(caseTypeLabel);
		
		JLabel fNameLabel = new JLabel("Client First Name:");
		fNameLabel.setForeground(Color.WHITE);
		fNameLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		fNameLabel.setBounds(471, 174, 126, 14);
		contentPane.add(fNameLabel);
		
		fNameTxtField = new JTextField();
		fNameTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				fNameTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		fNameTxtField.setForeground(Color.GRAY);
		fNameTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		fNameTxtField.setText("Enter first name");
		fNameTxtField.setToolTipText("Name must start with capital letter and cannot contain numbers");
		fNameTxtField.setBounds(593, 166, 140, 33);
		contentPane.add(fNameTxtField);
		fNameTxtField.setColumns(10);
		
		JLabel lNameLabel = new JLabel("Client Last Name:");
		lNameLabel.setForeground(Color.WHITE);
		lNameLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		lNameLabel.setBounds(471, 218, 126, 14);
		contentPane.add(lNameLabel);
		
		lNameTxtField = new JTextField();
		lNameTxtField.setText("Enter last name");
		lNameTxtField.setToolTipText("Name must start with capital letter and cannot contain numbers");
		lNameTxtField.setForeground(Color.GRAY);
		lNameTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		lNameTxtField.setColumns(10);
		lNameTxtField.setBounds(593, 210, 140, 33);
		lNameTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lNameTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(lNameTxtField);
		
		JLabel dobLabel = new JLabel("Client DOB:");
		dobLabel.setForeground(Color.WHITE);
		dobLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		dobLabel.setBounds(510, 275, 87, 14);
		contentPane.add(dobLabel);
		
		dobTxtField = new JTextField();
		dobTxtField.setText("DD/MM/YYYY");
		dobTxtField.setToolTipText("DOB must be entered in format DD/MM/YYYY");
		dobTxtField.setForeground(Color.GRAY);
		dobTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		dobTxtField.setColumns(10);
		dobTxtField.setBounds(593, 267, 140, 33);
		dobTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dobTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(dobTxtField);
		
		JLabel addressLabel = new JLabel("Client address:");
		addressLabel.setForeground(Color.WHITE);
		addressLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		addressLabel.setBounds(487, 335, 110, 14);
		contentPane.add(addressLabel);
		
		addressFirstLineTxtField = new JTextField();
		addressFirstLineTxtField.setText("Address line 1");
		addressFirstLineTxtField.setToolTipText("Enter Client's first line of address");
		addressFirstLineTxtField.setForeground(Color.GRAY);
		addressFirstLineTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		addressFirstLineTxtField.setColumns(10);
		addressFirstLineTxtField.setBounds(593, 327, 140, 33);
		addressFirstLineTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				addressFirstLineTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(addressFirstLineTxtField);
		
		addressSecondLineTxtField = new JTextField();
		addressSecondLineTxtField.setText("Address line 2");
		addressSecondLineTxtField.setToolTipText("Enter Client's second line of address");
		addressSecondLineTxtField.setForeground(Color.GRAY);
		addressSecondLineTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		addressSecondLineTxtField.setColumns(10);
		addressSecondLineTxtField.setBounds(593, 363, 140, 33);
		addressSecondLineTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				addressSecondLineTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(addressSecondLineTxtField);
		
		postcodeTxtField = new JTextField();
		postcodeTxtField.setText("Enter postcode");
		postcodeTxtField.setToolTipText("UK postcodes only. Case insensitive and no space required");
		postcodeTxtField.setForeground(Color.GRAY);
		postcodeTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		postcodeTxtField.setColumns(10);
		postcodeTxtField.setBounds(593, 407, 140, 33);
		postcodeTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				postcodeTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(postcodeTxtField);
		
		JLabel postcodeLabel = new JLabel("Client postcode:");
		postcodeLabel.setForeground(Color.WHITE);
		postcodeLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		postcodeLabel.setBounds(481, 415, 116, 14);
		contentPane.add(postcodeLabel);
		
		JLabel phoneNumLabel = new JLabel("Client phone no.:");
		phoneNumLabel.setForeground(Color.WHITE);
		phoneNumLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		phoneNumLabel.setBounds(481, 478, 116, 14);
		contentPane.add(phoneNumLabel);
		
		phoneNumTxtField = new JTextField();
		phoneNumTxtField.setText("Enter phone no.");
		phoneNumTxtField.setToolTipText("Must start with 0");
		phoneNumTxtField.setForeground(Color.GRAY);
		phoneNumTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		phoneNumTxtField.setColumns(10);
		phoneNumTxtField.setBounds(593, 470, 140, 33);
		phoneNumTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				phoneNumTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(phoneNumTxtField);
		
		JLabel enqTypeLabel = new JLabel("Enquiry Type:");
		enqTypeLabel.setForeground(Color.WHITE);
		enqTypeLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		enqTypeLabel.setBounds(497, 532, 110, 14);
		contentPane.add(enqTypeLabel);
		
		enqTypeComboBox = new JComboBox();
		enqTypeComboBox.setModel(new DefaultComboBoxModel(CaseType.values()));
		enqTypeComboBox.setToolTipText("Select a type from the list");
		enqTypeComboBox.setForeground(Color.BLACK);
		enqTypeComboBox.setFont(new Font("Verdana", Font.ITALIC, 10));
		enqTypeComboBox.setBounds(593, 524, 140, 33);
		enqTypeComboBox.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				enqTypeComboBoxActionPerformed(event);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to enqTypeComboBoxActionPerformed ActionListener
		contentPane.add(enqTypeComboBox);
		
		JLabel solLabel = new JLabel("Solicitor:");
		solLabel.setForeground(Color.WHITE);
		solLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		solLabel.setBounds(809, 174, 73, 14);
		contentPane.add(solLabel);
		
		String[] empNames = controller.getNames(employees);
		solComboBox = new JComboBox<Object>(empNames);
		solComboBox.setToolTipText("Select the Solicitor that will handle this Case");
		solComboBox.setForeground(Color.BLACK);
		solComboBox.setFont(new Font("Verdana", Font.ITALIC, 10));
		solComboBox.setBounds(881, 163, 140, 33);
		contentPane.add(solComboBox);
		
		JLabel caseTitleLabel = new JLabel("Case Title:");
		caseTitleLabel.setForeground(Color.WHITE);
		caseTitleLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		caseTitleLabel.setBounds(223, 219, 73, 14);
		caseTitleLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				caseTitleLabel.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(caseTitleLabel);
		
		caseTitleTxtField = new JTextField();
		caseTitleTxtField.setText("Enter case title");
		caseTitleTxtField.setToolTipText("Enter in format [Client surname] v [Opponent]");
		caseTitleTxtField.setForeground(Color.GRAY);
		caseTitleTxtField.setFont(new Font("Verdana", Font.PLAIN, 9));
		caseTitleTxtField.setColumns(10);
		caseTitleTxtField.setBounds(299, 207, 140, 33);
		//Clear the field ready for user input
		caseTitleTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				caseTitleTxtField.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(caseTitleTxtField);
		
		JLabel caseDescriptionLabel = new JLabel("Description:");
		caseDescriptionLabel.setForeground(Color.WHITE);
		caseDescriptionLabel.setFont(new Font("Verdana", Font.BOLD, 12));
		caseDescriptionLabel.setBounds(209, 255, 87, 14);
		contentPane.add(caseDescriptionLabel);
		
		caseDescriptionTxtArea = new JTextArea();
		caseDescriptionTxtArea.setLineWrap(true);
		caseDescriptionTxtArea.setForeground(Color.GRAY);
		caseDescriptionTxtArea.setFont(new Font("Verdana", Font.PLAIN, 10));
		caseDescriptionTxtArea.setText("Enter description here");
		caseDescriptionTxtArea.setToolTipText("Enter a brief description of the Case");
		caseDescriptionTxtArea.setBounds(299, 251, 140, 145);
		caseDescriptionTxtArea.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				caseDescriptionTxtArea.setText("");
			} //end method mouseClicked
		} //end method MouseAdapter
		); //end call to MouseListener
		contentPane.add(caseDescriptionTxtArea);
		
		confirmCaseButton = new JButton("Confirm New Case");
		confirmCaseButton.setBorder(null);
		confirmCaseButton.setBackground(new Color(144, 238, 144));
		confirmCaseButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		confirmCaseButton.setFont(new Font("Arial", Font.BOLD, 14));
		confirmCaseButton.setBounds(840, 554, 181, 85);
		confirmCaseButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				try {
					confirmCaseButtonActionPerformed(event, employees, clients, cases);
				} //end try 
				catch (ParseException e) {
					e.printStackTrace();
				} //end catch
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to confirmCaseButtonActionPerformed ActionListener
		contentPane.add(confirmCaseButton);

		setLocationRelativeTo(null);
	} //end method createNewCaseForm
	
	
	/**
	 * Method to reset all fields back to their original state.
	 * Used after a new Case is successfully confirmed.
	 */
	private void resetAllFields() {
		caseTitleTxtField.setText("Enter case title");
		caseTitleTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
		caseDescriptionTxtArea.setText("Enter description here");
		caseDescriptionTxtArea.setBorder(new EmptyBorder(5, 5, 5, 5));
		fNameTxtField.setText("Enter first name");
		fNameTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
		lNameTxtField.setText("Enter last name");
		lNameTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
		dobTxtField.setText("DD/MM/YYYY");
		dobTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
		addressFirstLineTxtField.setText("Address line 1");
		addressFirstLineTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
		addressSecondLineTxtField.setText("Address line 2");
		addressSecondLineTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
		postcodeTxtField.setText("Enter postcode");
		postcodeTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
		phoneNumTxtField.setText("Enter phone no.");
		phoneNumTxtField.setBorder(new EmptyBorder(5, 5, 5, 5));
	} //end method resetAllFields

	
	/*------------------------ACTION LISTENERS------------------------*/
	

	/**
	 * Method to set value of Enquiry Type combo box to match Case Type Combo Box.
	 * An Enquiry Type will always match a Case Type
	 * @param event the user selects a value in the Case Type Combo Box.
	 */
	private void caseTypeComboBoxActionPerformed(ActionEvent event) {
		enqTypeComboBox.setSelectedItem(caseTypeComboBox.getSelectedItem());
	} //end method caseTypeComboBoxButtonActionPerformed

	
	/**
	 * The routine to follow if the "Confirm Case" Button is pressed.
	 * @param event the "Confirm Case" button is pressed.
	 * @param employees the List of Employee objects to be searched.
	 * @param cases the List the new Case object will be added to.
	 * @param clients the List the Client object will be added to.
	 * @throws ParseException thrown if the DOB field cannot be parsed.
	 */
	private void confirmCaseButtonActionPerformed(ActionEvent event, ArrayList<Employee> employees, 
			ArrayList<Client> clients, ArrayList<Case> cases) throws ParseException {
		int emptyFields = controller.checkEmpty(caseTitleTxtField, caseDescriptionTxtArea, fNameTxtField, lNameTxtField,
				dobTxtField, addressFirstLineTxtField, addressSecondLineTxtField, postcodeTxtField,
				phoneNumTxtField);
		//if there's no empty fields
		if(emptyFields==0) { 
			boolean added = controller.addNewCase(caseTitleTxtField, caseTypeComboBox, caseDescriptionTxtArea, 
					solComboBox, fNameTxtField, lNameTxtField,
					dobTxtField, addressFirstLineTxtField, addressSecondLineTxtField, 
					postcodeTxtField, phoneNumTxtField, employees, clients, cases);
			if(added) { //if added is true
				resetAllFields();
			} else {
				commonElements.showError(controller.error11, "Invalid Fields");
			}
		} 
		else {//else field(s) empty
			commonElements.showError(controller.error2, "Empty fields");
		}//end if else
	} //end method confirmCaseButtonActionPerformed
	
	
	/**
	 * Method to set value of Case combo box to match Enquiry Type Combo Box.
	 * A Case Type will always match Enquiry Type.
	 * @param event the user selects a value in the Enquiry Type Combo Box.
	 */
	private void enqTypeComboBoxActionPerformed(ActionEvent event) {
		caseTypeComboBox.setSelectedItem(enqTypeComboBox.getSelectedItem());
	} //end method enqTypeComboBoxActionPerformed
} //end class AddCaseInterface