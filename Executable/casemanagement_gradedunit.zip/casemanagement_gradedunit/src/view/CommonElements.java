package view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.InputMismatchException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import model.Case;
import model.Client;
import model.Employee;
import use_case_controller.SearchCasesController;

/**
 * Class CommonElements to reduce repeating code in package view.
 * Responsible for constructing main navigation menu.
 * Contains other commonly used elements such as displaying an error message and styling a button.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class CommonElements extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private String error3 = "Please enter a valid case reference number.";

	//Controller required for use in Action Performed methods
	private SearchCasesController searchController = new SearchCasesController();
	
	// Instance fields for navigation menu
	private JPanel menuPanel;
	private JLabel menuLabel;
	private JButton addCaseBtn;
	private JButton viewAllCasesButton;
	private JButton viewCriminalBtn;
	private JButton viewImmBtn;
	private JButton viewPIBtn;
	private JButton ourStaffBtn;
	private JButton genReportBtn;
	private JTextField searchBarTxtField;
	private JButton searchButton;
	
	/**
	 * Method to construct the navigation menu.
	 * @param contentPane the JPanel to place menu on
	 * @param employees the List of Employee data required to add new Case 
	 * @param clients the List of Client data required to add new Case and Client
	 * @param cases the List of Case data which new Case is added to
	 */
	public void constructNavMenu(JPanel contentPane, ArrayList<Employee> employees, 
			ArrayList<Client> clients,
			ArrayList<Case> cases) {
		menuPanel = new JPanel();
		menuPanel.setBackground(Color.LIGHT_GRAY);
		menuPanel.setBounds(10, 11, 181, 646);
		contentPane.add(menuPanel);
		menuPanel.setLayout(null);
		
		menuLabel = new JLabel("MENU");
		menuLabel.setBounds(58, 11, 70, 23);
		menuLabel.setFont(new Font("Verdana", Font.BOLD, 18));
		menuPanel.add(menuLabel);
		
		addCaseBtn = new JButton("Add New Case");
		addCaseBtn.setBounds(11, 44, 160, 75);
		styleButton(addCaseBtn);
		addCaseBtn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				addCaseBtnActionPerformed(event, employees, clients, cases);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to addCaseBtnActionPerformed ActionListener
		menuPanel.add(addCaseBtn);
		
		viewAllCasesButton = new JButton("View All Cases");
		viewAllCasesButton.setBounds(11, 130, 160, 75);
		styleButton(viewAllCasesButton);
		viewAllCasesButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				viewAllCasesButtonActionPerformed(event, employees, clients, cases);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to viewAllCasesButtonActionPerformed ActionListener
		menuPanel.add(viewAllCasesButton);
		
		viewCriminalBtn = new JButton("View Criminal Cases");
		viewCriminalBtn.setBounds(11, 216, 160, 75);
		styleButton(viewCriminalBtn);
		menuPanel.add(viewCriminalBtn);
		
		viewImmBtn = new JButton("View Imm Cases");
		viewImmBtn.setBounds(11, 302, 160, 75);
		styleButton(viewImmBtn);
		menuPanel.add(viewImmBtn);
		
		viewPIBtn = new JButton("View PI Cases");
		viewPIBtn.setBounds(11, 388, 160, 75);
		styleButton(viewPIBtn);
		menuPanel.add(viewPIBtn);
		
		ourStaffBtn = new JButton("Our Staff");
		ourStaffBtn.setBounds(11, 474, 160, 75);
		styleButton(ourStaffBtn);
		menuPanel.add(ourStaffBtn);
		
		genReportBtn = new JButton("Generate Report");
		genReportBtn.setBounds(11, 560, 160, 75);
		styleButton(genReportBtn);
		menuPanel.add(genReportBtn);
		
		searchBarTxtField = new JTextField();
		searchBarTxtField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				searchBarTxtField.setText("");
			}
		});
		searchBarTxtField.setFont(new Font("Verdana", Font.PLAIN, 14));
		searchBarTxtField.setText("Enter a Case Reference Number");
		searchBarTxtField.setBounds(238, 40, 443, 56);
		contentPane.add(searchBarTxtField);
		searchBarTxtField.setColumns(10);
		
		searchButton = new JButton("Search");
		searchButton.setBounds(723, 49, 116, 40);
		styleButton(searchButton);
		searchButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				searchButtonActionPerformed(event, cases, employees, clients);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to addCaseBtnActionPerformed ActionListener
		contentPane.add(searchButton);
	} //end method constructNavMenu
	
	/**
	 * Method to outline a JTextField red.
	 * Used when invalid data is entered.
	 * @param textField the JTextField to be outlined.
	 */
	public void outlineRed(JTextField textField) {
		textField.setBorder(new LineBorder(Color.RED, 2));
	} //end method outline Red
	
	/**
	 * Method to display error message to screen.
	 * @param errorMessage the error message to be displayed.
	 * @param title the title of the JOptionPane.
	 */
	public void showError(String errorMessage, String title) {
		JOptionPane.showMessageDialog(null, errorMessage, title, JOptionPane.ERROR_MESSAGE);
	} //end method showError
	
	/**
	 * Method to style a button.
	 * @param btn the JButton to be styled.
	 */
	public void styleButton(JButton btn) {
		btn.setBorder(null);
		btn.setForeground(Color.WHITE);
		btn.setBackground(Color.BLACK);
		btn.setFont(new Font("Verdana", Font.BOLD, 12));
		btn.setAlignmentX(Component.CENTER_ALIGNMENT);
	} //end method styleButton
	
	/*------------------------ACTION LISTENERS------------------------*/
	
	/**
	 * The routine to follow if "Add New Case" button is pressed.
	 * Constructs AddCaseInterface object to display new window to screen.
	 * @param event the "Add New Case" button is pressed.
	 * @param employees the List of Employee data required to be searched.
	 * @param clients the List of Client data to be added to.
	 * @param cases the List of Case data to be added to.
	 */
	private void addCaseBtnActionPerformed(ActionEvent event, ArrayList<Employee> employees, 
			ArrayList<Client> clients, ArrayList<Case> cases) {
		this.setVisible(false);
		AddCaseInterface newCaseForm = new AddCaseInterface(employees, clients, cases);
		newCaseForm.setVisible(true);
	} //end method addCaseBtnActionPerformed
	
	/**
	 * The routine to follow if the Search Button has been pressed.
	 * @param event the Search Button has been pressed.
	 * @param cases the List of Cases 
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 */
	private void searchButtonActionPerformed(ActionEvent event, ArrayList<Case> cases, ArrayList<Employee> employees, ArrayList<Client> clients) {
		String caseNum = searchBarTxtField.getText();
		try {
			Client client = searchController.findCase(clients, caseNum);
			if(client == null) {
				showError(error3, "Case Not Found");
			} else {
				this.dispose();
				SearchResultInterface searchResults = new SearchResultInterface(employees, clients, cases, caseNum);
				searchResults.setVisible(true);
			} //end if else
		} //end try
		catch(InputMismatchException e) {
			System.out.println("Case does not exist");
		} //end catch
	} //end method searchButtonActionPerformed

	/**
	 * The routine to follow if "View Caseload" Button is pressed.
	 * Outputs data to console for testing purposes.
	 * @param event the "View Caseload" Button in navigation panel is pressed.
	 * @param clients the List from which data is retrieved.
	 */
	private void viewAllCasesButtonActionPerformed(ActionEvent event, ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) {
		//searchController.viewAllCases(tArea, clients);
		this.dispose();
		SearchResultInterface searchResults = new SearchResultInterface(employees, clients, cases);
		searchResults.setVisible(true);
	} //end method viewAllCasesButtonActionPerformed
} //end class CommonElements