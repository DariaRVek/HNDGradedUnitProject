package view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

import model.Case;
import model.Client;
import model.Employee;
import use_case_controller.SearchCasesController;

/**
 * Class AddCaseInterface to construct interface for user to add a new Case.
 * Interacts with NewCaseController to ensure data input is valid.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class HomeInterface extends JFrame {

	private static final long serialVersionUID = 1L;
	private CommonElements commonElements = new CommonElements();
	private SearchCasesController searchController = new SearchCasesController();
	private JPanel contentPane;
	private JPanel totalCasesPanel;
	private JTextArea totalCasesTxtArea;
	private JTextPane totalCasesTxtPane;
	//Labels for images
	private JLabel imgLabelTotal;
	private JLabel imgLabelImm;
	private JLabel imgLabelCri;
	private JLabel imgLabelPI;

	/**
	 * Constructor method to create HomeInterface object.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 */
	public HomeInterface(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) {
		createHomeInterface(employees, clients, cases);
	} //end constructor method
	
	/**
	 * Method to create the home GUI.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 */
	private void createHomeInterface(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases){
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 700);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		commonElements.constructNavMenu(contentPane, employees, clients, cases);
		
		totalCasesPanel = new JPanel();
		totalCasesPanel.setBounds(238, 190, 276, 155);
		contentPane.add(totalCasesPanel);
		totalCasesPanel.setLayout(null);
		
		ImageIcon icon = createImageIcon("/img/mallett.png", "Image of mallett for decoration purposes");
		imgLabelTotal = new JLabel(icon);
		imgLabelTotal.setBounds(15, 17, 106, 122);
		totalCasesPanel.add(imgLabelTotal);
		
		totalCasesTxtArea = new JTextArea();
		totalCasesTxtArea.setBounds(184, 51, 90, 49);
		totalCasesPanel.add(totalCasesTxtArea);
		totalCasesTxtArea.setAlignmentX(Component.RIGHT_ALIGNMENT);
		totalCasesTxtArea.setWrapStyleWord(true);
		totalCasesTxtArea.setFont(new Font("Arial", Font.BOLD, 14));
		totalCasesTxtArea.setText("Total Cases:\r\n" + cases.size());
		totalCasesTxtArea.setBackground(new Color(245, 255, 250));
		
		totalCasesTxtPane = new JTextPane();
		totalCasesTxtPane.setBounds(0, 0, 276, 155);
		totalCasesPanel.add(totalCasesTxtPane);
		totalCasesTxtPane.setEditable(false);
		totalCasesTxtPane.setBackground(new Color(245, 255, 250));
		totalCasesTxtPane.setFont(new Font("Arial", Font.BOLD, 14));
		
		JPanel criCasesPanel = new JPanel();
		criCasesPanel.setLayout(null);
		criCasesPanel.setBounds(588, 190, 276, 155);
		contentPane.add(criCasesPanel);
		
		imgLabelCri = new JLabel(icon);
		imgLabelCri.setBounds(15, 17, 106, 122);
		criCasesPanel.add(imgLabelCri);
		
		JTextArea criminalCasesTxtArea = new JTextArea();
		criminalCasesTxtArea.setWrapStyleWord(true);
		criminalCasesTxtArea.setText("Criminal Cases:\r\n" + searchController.countCrimCases(cases));
		criminalCasesTxtArea.setFont(new Font("Arial", Font.BOLD, 14));
		criminalCasesTxtArea.setBackground(new Color(245, 255, 250));
		criminalCasesTxtArea.setAlignmentX(1.0f);
		criminalCasesTxtArea.setBounds(161, 51, 113, 49);
		criCasesPanel.add(criminalCasesTxtArea);
		
		JTextPane criminalCasesTxtPane = new JTextPane();
		criminalCasesTxtPane.setFont(new Font("Arial", Font.BOLD, 14));
		criminalCasesTxtPane.setEditable(false);
		criminalCasesTxtPane.setBackground(new Color(245, 255, 250));
		criminalCasesTxtPane.setBounds(0, 0, 276, 155);
		criCasesPanel.add(criminalCasesTxtPane);
		
		JPanel immCasesPanel = new JPanel();
		immCasesPanel.setLayout(null);
		immCasesPanel.setBounds(238, 434, 276, 155);
		contentPane.add(immCasesPanel);
		
		imgLabelImm = new JLabel(icon);
		imgLabelImm.setBounds(15, 17, 106, 122);
		immCasesPanel.add(imgLabelImm);
		
		JTextArea immCasesTxtArea = new JTextArea();
		immCasesTxtArea.setWrapStyleWord(true);
		immCasesTxtArea.setText("Immigration Cases:\r\n" + searchController.countImmCases(cases));
		immCasesTxtArea.setFont(new Font("Arial", Font.BOLD, 14));
		immCasesTxtArea.setBackground(new Color(245, 255, 250));
		immCasesTxtArea.setAlignmentX(1.0f);
		immCasesTxtArea.setBounds(136, 51, 138, 49);
		immCasesPanel.add(immCasesTxtArea);
		
		JTextPane immCasesTxtPane = new JTextPane();
		immCasesTxtPane.setFont(new Font("Arial", Font.BOLD, 14));
		immCasesTxtPane.setEditable(false);
		immCasesTxtPane.setBackground(new Color(245, 255, 250));
		immCasesTxtPane.setBounds(0, 0, 276, 155);
		immCasesPanel.add(immCasesTxtPane);
		
		JPanel pInjuryCasesPanel = new JPanel();
		pInjuryCasesPanel.setLayout(null);
		pInjuryCasesPanel.setBounds(588, 434, 276, 155);
		contentPane.add(pInjuryCasesPanel);
		
		imgLabelPI = new JLabel(icon);
		imgLabelPI.setBounds(15, 17, 106, 122);
		pInjuryCasesPanel.add(imgLabelPI);
		
		JTextArea pInjuryCasesTxtArea = new JTextArea();
		pInjuryCasesTxtArea.setWrapStyleWord(true);
		pInjuryCasesTxtArea.setText("PI Cases:\r\n" + searchController.countPICases(cases));
		pInjuryCasesTxtArea.setFont(new Font("Arial", Font.BOLD, 14));
		pInjuryCasesTxtArea.setBackground(new Color(245, 255, 250));
		pInjuryCasesTxtArea.setAlignmentX(1.0f);
		pInjuryCasesTxtArea.setBounds(205, 51, 69, 49);
		pInjuryCasesPanel.add(pInjuryCasesTxtArea);
		
		JTextPane pInjuryCasesTxtPane = new JTextPane();
		pInjuryCasesTxtPane.setFont(new Font("Arial", Font.BOLD, 14));
		pInjuryCasesTxtPane.setEditable(false);
		pInjuryCasesTxtPane.setBackground(new Color(245, 255, 250));
		pInjuryCasesTxtPane.setBounds(0, 0, 276, 155);
		pInjuryCasesPanel.add(pInjuryCasesTxtPane);
		
		setTitle("McRae&DICK Case Management System");
		setLocationRelativeTo(null);
	} //end method createHomeInterface
	
	//Method taken from: https://docs.oracle.com/javase/tutorial/uiswing/components/icon.html
	/** Returns an ImageIcon, or null if the path was invalid. */
	protected ImageIcon createImageIcon(String path,
	                                           String description) {
	    java.net.URL imgURL = getClass().getResource(path);
	    if (imgURL != null) {
	        return new ImageIcon(imgURL, description);
	    } else {
	        System.err.println("Couldn't find file: " + path);
	        return null;
	    }
	}
} //end class HomeInterface