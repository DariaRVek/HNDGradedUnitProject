package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import model.Case;
import model.Client;
import model.Employee;
import use_case_controller.LogInController;

/**
 * Class LogInInterface to construct interface presented after successful login.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class LogInInterface extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField usernameTextField;
	private JPasswordField passwordField;
	private JLabel resetLink;
	private JButton signInButton;
	private LogInController controller = new LogInController();
	private CommonElements common = new CommonElements();
	
	/**
	 * Constructor method to create LogInInterface object.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 */
	public LogInInterface(ArrayList<Employee> employees, ArrayList<Client> clients,
			ArrayList<Case> cases) {
		createLogInInterface(employees, clients, cases);
	} //end constructor method
	
	/**
	 * Method to create the GUI to allow a user to log in to system.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 */
	private void createLogInInterface(ArrayList<Employee> employees, ArrayList<Client> clients,
			ArrayList<Case> cases) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 622, 644);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel imgLabel = new JLabel("");
		imgLabel.setIcon(new ImageIcon(LogInInterface.class.getResource("/img/Logo.png")));
		imgLabel.setBounds(142, 11, 300, 300);
		contentPane.add(imgLabel);
		
		usernameTextField = new JTextField(30);
		usernameTextField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				usernameTextField.setText("");
			}
		});
		usernameTextField.setToolTipText("Enter your username here");
		usernameTextField.setFont(new Font("Verdana", Font.PLAIN, 14));
		usernameTextField.setText("Username");
		usernameTextField.setBounds(152, 325, 283, 37);
		contentPane.add(usernameTextField);
		usernameTextField.setColumns(10);
		
		passwordField = new JPasswordField(25);
		passwordField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				passwordField.setText("");
			}
		});
		passwordField.setFont(new Font("Verdana", Font.PLAIN, 14));
		passwordField.setToolTipText("Enter your password here");
		//passwordField.setText("Password");
		passwordField.setBounds(152, 373, 283, 37);
		contentPane.add(passwordField);
		passwordField.setColumns(10);
		
		resetLink = new JLabel("Click here to set or change your password");
		resetLink.setFont(new Font("Verdana", Font.PLAIN, 12));
		resetLink.setBounds(155, 421, 300, 21);
		resetLink.setForeground(Color.blue.darker());
		resetLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		resetLink.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				resetLinkClicked(e, employees, cases, clients);
			}
		});
		contentPane.add(resetLink);
		
		signInButton = new JButton("Sign In");
		common.styleButton(signInButton);
		signInButton.setBounds(211, 466, 154, 37);
		signInButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				signInButtonActionPerformed(event, employees, cases, clients);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to signInButtonActionPerformed ActionListener
		contentPane.add(signInButton);
		
		// set properties of application's window
		setTitle("McRae & Dick Log In"); // set title bar string
		setLocationRelativeTo(null);
		setVisible(true);
	} //end method createLogInInterface
	
	/**
	 * Routine to be followed when link to reset password is clicked.
	 * @param event the "Reset Password" link is clicked
	 * @param employees the List of Employees
	 * @param cases the List of Cases
	 * @param clients the List of Clients
	 */
	private void resetLinkClicked(MouseEvent event, ArrayList<Employee> employees,
			ArrayList<Case> cases, ArrayList<Client> clients) {
		//if the user clicks the link we want to display the ResetPassword window
		this.setVisible(false);
		ResetPasswordInterface rp = new ResetPasswordInterface(employees, cases, clients);
		rp.setVisible(true);
	} //end method resetLinkClicked
	
	/**
	 * Routine to be followed when "Sign In" button is pressed.
	 * @param event the "Sign In" button is pressed
	 * @param employees the List of Employees
	 * @param cases the List of Cases
	 * @param clients the List of Clients
	 */
	private void signInButtonActionPerformed(ActionEvent event, ArrayList<Employee> employees,
			ArrayList<Case> cases, ArrayList<Client> clients) {
		if(controller.signIn(usernameTextField, passwordField)) {
			this.dispose();
			HomeInterface home = new HomeInterface(employees, clients, cases);
			home.setVisible(true);
		} //endif
	} //end method signInButtonActionPerformed
} //end class LogInInterface