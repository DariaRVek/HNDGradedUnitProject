package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import model.Case;
import model.Client;
import model.Employee;
import use_case_controller.LogInController;

/**
 * Class ResetPasswordInterface to construct interface for user to reset their password.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class ResetPasswordInterface  extends JFrame {

	private static final long serialVersionUID = 1L;
	// Instance fields
	private JPanel contentPane;
	private JTextField usernameTextField;
	private JPasswordField oldPasswordTextField;
	private JPasswordField newPasswordTextField;
	private JButton resetPWBtn;
	//Controller instance for validation and data flow control
	private LogInController loginController = new LogInController();
	
	/**
	 * Constructor method to create user interface that allows for resetting of password.
	 * @param employees the List of Employees needed to create LogInInterface if reset successful.
	 * @param cases the List of Cases needed to create LogInInterface if reset successful.
	 * @param clients the List of Clients needed to create LogInInterface if reset successful.
	 */
	public ResetPasswordInterface(ArrayList<Employee> employees,
			ArrayList<Case> cases, ArrayList<Client> clients) {
		constructResetPasswordInterface(employees, cases, clients);
	} //end constructor method

	/**
	 * Method to create the Reset Password interface.
	 * @param employees the List of Employees needed to create LogInInterface if reset successful.
	 * @param cases the List of Cases needed to create LogInInterface if reset successful.
	 * @param clients the List of Clients needed to create LogInInterface if reset successful.
	 */
	private void constructResetPasswordInterface(ArrayList<Employee> employees,
			ArrayList<Case> cases, ArrayList<Client> clients) {
		setTitle("Set Password");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 339, 264);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel usernameLabel = new JLabel("Enter username:");
		usernameLabel.setBounds(36, 53, 107, 14);
		contentPane.add(usernameLabel);

		JLabel oldPasswordLabel = new JLabel("Old password:");
		oldPasswordLabel.setBounds(36, 95, 88, 14);
		contentPane.add(oldPasswordLabel);

		JLabel newPasswordLabel = new JLabel("New password:");
		newPasswordLabel.setBounds(36, 135, 88, 14);
		contentPane.add(newPasswordLabel);

		usernameTextField = new JTextField();
		usernameTextField.setBounds(151, 50, 128, 20);
		contentPane.add(usernameTextField);
		usernameTextField.setColumns(10);

		oldPasswordTextField = new JPasswordField();
		oldPasswordTextField.setColumns(10);
		oldPasswordTextField.setBounds(151, 92, 128, 20);
		contentPane.add(oldPasswordTextField);

		newPasswordTextField = new JPasswordField();
		newPasswordTextField.setColumns(10);
		newPasswordTextField.setBounds(151, 132, 128, 20);
		contentPane.add(newPasswordTextField);

		resetPWBtn = new JButton("Reset Password");
		resetPWBtn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent event) {
			resetPWBtnActionPerformed(event, employees, cases, clients);
		} //end method actionPerformed
		} //end method ActionListener
		); //end call to resetPWBtnActionPerformed ActionListener
		resetPWBtn.setBounds(104, 182, 153, 23);
		contentPane.add(resetPWBtn);
	} // end method constructResetPasswordInterface
	
	/**
	 * Routine to be followed if Reset Password button is pressed.
	 * @param event the Reset Password button is pressed.
	 * @param employees the List of Employees needed to create LogInInterface if reset successful.
	 * @param cases the List of Cases needed to create LogInInterface if reset successful.
	 * @param clients the List of Clients needed to create LogInInterface if reset successful.
	 */
	private void resetPWBtnActionPerformed(ActionEvent event, ArrayList<Employee> employees,
			ArrayList<Case> cases, ArrayList<Client> clients) {
		if(loginController.resetPassword(usernameTextField, oldPasswordTextField, newPasswordTextField)) {
			this.dispose();
			LogInInterface login = new LogInInterface(employees, clients, cases);
			login.setVisible(true);
		} //endif
	} //end method resetPWBtnActionPerformed
} //end class ResetPasswordInterface