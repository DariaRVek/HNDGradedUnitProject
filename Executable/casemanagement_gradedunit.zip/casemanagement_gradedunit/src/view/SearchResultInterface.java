package view;

import java.awt.Color;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;

import model.Case;
import model.Client;
import model.Employee;
import use_case_controller.SearchCasesController;

/**
 * Class SearchResultInterface to construct interface to display search results.
 * @author Daria Vekic (Student ID: 586661)
 *
 */
public class SearchResultInterface extends JFrame {
	
	private static final long serialVersionUID = 1L;
	//Instance fields
	private JPanel contentPane;
	private JLabel caseRefDataLbl = new JLabel();
	private JLabel caseTitleDataLbl = new JLabel();
	private JLabel caseTypeDataLbl = new JLabel();
	private JLabel solNameDataLbl = new JLabel();
	private JLabel caseDescDataLbl = new JLabel();
	private JLabel clientNameDataLbl = new JLabel();
	private JLabel clientPhoneDataLbl = new JLabel();
	private JLabel clientAddressDataLbl = new JLabel();
	private static JTextArea displayJTextArea;
	
	private CommonElements commonElements = new CommonElements();
	private SearchCasesController searchController = new SearchCasesController();
	
	/**
	 * Constructor method to create SearchResultInterface object.
	 * Used to display details of all Cases in the List.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 */
	public SearchResultInterface(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) {
		showAllCasesGui(employees, clients, cases);
		searchController.viewAllCases(displayJTextArea, clients);
	} //end constructor method
	
	/**
	 * Constructor method to create SearchResultInterface object.
	 * Used to display details of a given Case.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 * @param caseNum the reference number of the Case to be displayed
	 */
	public SearchResultInterface(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases, String caseNum) {
		constructSearchResultGui(employees, clients, cases);
		searchController.listCase(clients, caseNum, 
				caseRefDataLbl, caseTitleDataLbl, caseTypeDataLbl, 
				solNameDataLbl, caseDescDataLbl, clientNameDataLbl,
				clientPhoneDataLbl, clientAddressDataLbl);
	} //end constructor method

	
	/**
	 * Method to create GUI that displays Case details user has searched for.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 */
	private void constructSearchResultGui(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) {
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setBounds(100, 100, 1100, 710);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//add the navigation menu to the GUI
		commonElements.constructNavMenu(contentPane, employees, clients, cases);
		
		//Panel to place search results on
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(233, 150, 653, 403);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel actionsLbl = new JLabel("Actions:");
		actionsLbl.setBounds(43, 21, 71, 29);
		actionsLbl.setBackground(Color.LIGHT_GRAY);
		actionsLbl.setFont(new Font("Tahoma", Font.BOLD, 14));
		panel.add(actionsLbl);
		
		JLabel clientAddressLbl = new JLabel("Client Address");
		clientAddressLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		clientAddressLbl.setBackground(Color.LIGHT_GRAY);
		clientAddressLbl.setBounds(38, 374, 84, 15);
		panel.add(clientAddressLbl);
		
		JLabel clientPhoneLbl = new JLabel("Client Phone Number");
		clientPhoneLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		clientPhoneLbl.setBackground(Color.LIGHT_GRAY);
		clientPhoneLbl.setBounds(22, 332, 122, 15);
		panel.add(clientPhoneLbl);
		
		JLabel clientNameLbl = new JLabel("Client Name");
		clientNameLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		clientNameLbl.setBackground(Color.LIGHT_GRAY);
		clientNameLbl.setBounds(43, 292, 71, 15);
		panel.add(clientNameLbl);
		
		JLabel descLbl = new JLabel("Case Description");
		descLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		descLbl.setBackground(Color.LIGHT_GRAY);
		descLbl.setBounds(30, 252, 96, 15);
		panel.add(descLbl);
		
		JLabel solLbl = new JLabel("Solicitor");
		solLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		solLbl.setBackground(Color.LIGHT_GRAY);
		solLbl.setBounds(54, 212, 51, 15);
		panel.add(solLbl);
		
		JLabel caseTypeLbl = new JLabel("Case Type");
		caseTypeLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		caseTypeLbl.setBackground(Color.LIGHT_GRAY);
		caseTypeLbl.setBounds(43, 173, 62, 15);
		panel.add(caseTypeLbl);
		
		JLabel caseTitleLbl = new JLabel("Case Title");
		caseTitleLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		caseTitleLbl.setBackground(Color.LIGHT_GRAY);
		caseTitleLbl.setBounds(43, 131, 62, 15);
		panel.add(caseTitleLbl);
		
		JLabel caseRefLbl = new JLabel("Case Ref No.");
		caseRefLbl.setFont(new Font("Tahoma", Font.PLAIN, 12));
		caseRefLbl.setBackground(Color.LIGHT_GRAY);
		caseRefLbl.setBounds(38, 83, 76, 15);
		panel.add(caseRefLbl);
		
		JSeparator separator = new JSeparator();
		separator.setBackground(Color.GRAY);
		separator.setOpaque(true);
		separator.setForeground(Color.GRAY);
		separator.setBounds(153, 0, 2, 403);
		panel.add(separator);
		
		JSeparator separator1 = new JSeparator();
		separator1.setOpaque(true);
		separator1.setForeground(Color.GRAY);
		separator1.setBackground(Color.GRAY);
		separator1.setBounds(0, 70, 653, 2);
		panel.add(separator1);
	
		JSeparator separator2 = new JSeparator();
		separator2.setOpaque(true);
		separator2.setForeground(Color.GRAY);
		separator2.setBackground(Color.GRAY);
		separator2.setBounds(0, 112, 653, 2);
		panel.add(separator2);
		
		JSeparator separator3 = new JSeparator();
		separator3.setOpaque(true);
		separator3.setForeground(Color.GRAY);
		separator3.setBackground(Color.GRAY);
		separator3.setBounds(0, 157, 653, 2);
		panel.add(separator3);
		
		JSeparator separator4 = new JSeparator();
		separator4.setOpaque(true);
		separator4.setForeground(Color.GRAY);
		separator4.setBackground(Color.GRAY);
		separator4.setBounds(0, 199, 653, 2);
		panel.add(separator4);
		
		JSeparator separator5 = new JSeparator();
		separator5.setOpaque(true);
		separator5.setForeground(Color.GRAY);
		separator5.setBackground(Color.GRAY);
		separator5.setBounds(0, 239, 653, 2);
		panel.add(separator5);
		
		JSeparator separator6 = new JSeparator();
		separator6.setOpaque(true);
		separator6.setForeground(Color.GRAY);
		separator6.setBackground(Color.GRAY);
		separator6.setBounds(0, 279, 653, 2);
		panel.add(separator6);
		
		JSeparator separator7 = new JSeparator();
		separator7.setOpaque(true);
		separator7.setForeground(Color.GRAY);
		separator7.setBackground(Color.GRAY);
		separator7.setBounds(0, 319, 653, 2);
		panel.add(separator7);
		
		JSeparator separator8 = new JSeparator();
		separator8.setOpaque(true);
		separator8.setForeground(Color.GRAY);
		separator8.setBackground(Color.GRAY);
		separator8.setBounds(0, 361, 653, 2);
		panel.add(separator8);
		
		JLabel actionsBckgrdLbl = new JLabel("");
		actionsBckgrdLbl.setOpaque(true);
		actionsBckgrdLbl.setBackground(new Color(204, 204, 204));
		actionsBckgrdLbl.setForeground(Color.BLACK);
		actionsBckgrdLbl.setBounds(0, 0, 153, 72);
		panel.add(actionsBckgrdLbl);
		
		JLabel caseRefBckgrdLbl = new JLabel("");
		caseRefBckgrdLbl.setOpaque(true);
		caseRefBckgrdLbl.setBackground(new Color(204, 204, 204));
		caseRefBckgrdLbl.setBounds(0, 70, 155, 42);
		panel.add(caseRefBckgrdLbl);
		
		JLabel caseTitleBckgrdLbl = new JLabel("");
		caseTitleBckgrdLbl.setOpaque(true);
		caseTitleBckgrdLbl.setBackground(new Color(204, 204, 204));
		caseTitleBckgrdLbl.setBounds(0, 114, 155, 45);
		panel.add(caseTitleBckgrdLbl);
		
		JLabel caseTypeBckgrdLbl = new JLabel("");
		caseTypeBckgrdLbl.setOpaque(true);
		caseTypeBckgrdLbl.setBackground(new Color(204, 204, 204));
		caseTypeBckgrdLbl.setBounds(0, 157, 155, 42);
		panel.add(caseTypeBckgrdLbl);
		
		JLabel solBckgrdLbl = new JLabel("");
		solBckgrdLbl.setOpaque(true);
		solBckgrdLbl.setBackground(new Color(204, 204, 204));
		solBckgrdLbl.setBounds(0, 199, 155, 42);
		panel.add(solBckgrdLbl);
		
		JLabel caseDescBckgrdLbl = new JLabel("");
		caseDescBckgrdLbl.setOpaque(true);
		caseDescBckgrdLbl.setBackground(new Color(204, 204, 204));
		caseDescBckgrdLbl.setBounds(0, 239, 155, 42);
		panel.add(caseDescBckgrdLbl);
		
		JLabel clientNameBckgrdLbl = new JLabel("");
		clientNameBckgrdLbl.setOpaque(true);
		clientNameBckgrdLbl.setBackground(new Color(204, 204, 204));
		clientNameBckgrdLbl.setBounds(0, 279, 155, 42);
		panel.add(clientNameBckgrdLbl);
		
		JLabel clientPhoneBckgrdLbl = new JLabel("");
		clientPhoneBckgrdLbl.setOpaque(true);
		clientPhoneBckgrdLbl.setBackground(new Color(204, 204, 204));
		clientPhoneBckgrdLbl.setBounds(0, 320, 155, 42);
		panel.add(clientPhoneBckgrdLbl);
		
		JLabel clientAddressBckgrdLbl = new JLabel("");
		clientAddressBckgrdLbl.setOpaque(true);
		clientAddressBckgrdLbl.setBackground(new Color(204, 204, 204));
		clientAddressBckgrdLbl.setBounds(0, 361, 155, 42);
		panel.add(clientAddressBckgrdLbl);
		
		JButton recordActivityBtn = new JButton("Record Billable Activity");
		recordActivityBtn.setFont(new Font("Tahoma", Font.BOLD, 12));
		recordActivityBtn.setBorder(null);
		recordActivityBtn.setBackground(new Color(153, 204, 153));
		recordActivityBtn.setBounds(185, 23, 172, 29);
		recordActivityBtn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				recordActivityBtnActionPerformed(event);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to recordActivityBtnActionPerformed ActionListener
		panel.add(recordActivityBtn);
		
		JButton amendCaseDetailsBtn = new JButton("Amend Case Details");
		amendCaseDetailsBtn.setFont(new Font("Tahoma", Font.BOLD, 12));
		amendCaseDetailsBtn.setBorder(null);
		amendCaseDetailsBtn.setBackground(new Color(153, 204, 153));
		amendCaseDetailsBtn.setBounds(419, 22, 172, 29);
		amendCaseDetailsBtn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
				amendCaseDetailsBtnActionPerformed(event);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to confirmCaseButtonActionPerformed ActionListener
		panel.add(amendCaseDetailsBtn);
		
		caseRefDataLbl.setBounds(185, 83, 153, 18);
		panel.add(caseRefDataLbl);
		
		caseTitleDataLbl.setBounds(185, 128, 327, 18);
		panel.add(caseTitleDataLbl);
		
		caseTypeDataLbl.setBounds(185, 170, 327, 18);
		panel.add(caseTypeDataLbl);
		
		solNameDataLbl.setBounds(185, 210, 327, 18);
		panel.add(solNameDataLbl);
		
		caseDescDataLbl.setBounds(185, 250, 439, 18);
		panel.add(caseDescDataLbl);
		
		clientNameDataLbl.setBounds(185, 292, 268, 18);
		panel.add(clientNameDataLbl);
		
		clientPhoneDataLbl.setBounds(185, 332, 268, 18);
		panel.add(clientPhoneDataLbl);
		
		clientAddressDataLbl.setBounds(185, 375, 425, 18);
		panel.add(clientAddressDataLbl);
		
		JButton deleteCaseBtn = new JButton("Delete Case");
		deleteCaseBtn.setForeground(Color.WHITE);
		deleteCaseBtn.setFont(new Font("Tahoma", Font.BOLD, 12));
		deleteCaseBtn.setBorder(null);
		deleteCaseBtn.setBackground(Color.RED);
		deleteCaseBtn.setBounds(746, 590, 140, 29);
		deleteCaseBtn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) {
					deleteCaseButtonActionPerformed(event);
			} //end method actionPerformed
		} //end method ActionListener	
		); //end call to confirmCaseButtonActionPerformed ActionListener
		contentPane.add(deleteCaseBtn);
	} //end method constructSearchResultGui
	
	/**
	 * Method to create GUI that displays details of all Cases in the List.
	 * @param employees the List of Employees
	 * @param clients the List of Clients
	 * @param cases the List of Cases
	 */
	private void showAllCasesGui(ArrayList<Employee> employees, ArrayList<Client> clients, ArrayList<Case> cases) {
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setBounds(100, 100, 1100, 710);
		contentPane = new JPanel();
		contentPane.setBackground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//add the navigation menu to the GUI
		commonElements.constructNavMenu(contentPane, employees, clients, cases);
		
		// set up displayJTextArea
		displayJTextArea = new JTextArea();
		displayJTextArea.setBackground(Color.WHITE);
		JScrollPane scrollPane = new JScrollPane(displayJTextArea);
		scrollPane.setBounds(300, 150, 600, 450);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollPane);
		displayJTextArea.setText("Caseload");
		displayJTextArea.setForeground(Color.BLACK);
		
	} //end method showAllCasesGui
	
	
	/*------------------------ACTION LISTENERS------------------------*/
	
	
	/**
	 * Routine to follow when "Amend Case Details" button is pressed.
	 * @param event the "Amend Case Details" button is pressed.
	 */
	private void amendCaseDetailsBtnActionPerformed(ActionEvent event) {
		JOptionPane.showMessageDialog(null, "You will be able to amend Case details here in later versions!", "Oops!", JOptionPane.INFORMATION_MESSAGE);
	} //end method amendCaseDetailsBtnActionPerformed
	
	/**
	 * Routine to follow when "Delete Case" button is pressed.
	 * @param event the "Delete Case" button is pressed.
	 */
	private void deleteCaseButtonActionPerformed(ActionEvent event) {
		JOptionPane.showMessageDialog(null, "You will be able to delete a Case here in later versions!", "Oops!", JOptionPane.INFORMATION_MESSAGE);
	} //end method deleteCaseButtonActionPerformed
	
	/**
	 * Routine to follow when "Record Billable Activity" button is pressed.
	 * @param event the "Record Billable Activity" button is pressed.
	 */
	private void recordActivityBtnActionPerformed(ActionEvent event) {
		JOptionPane.showMessageDialog(null, "You will be able to record billable activities here in later versions!", "Oops!", JOptionPane.INFORMATION_MESSAGE);
	} //end method recordActivityBtnActionPerformed
} //end class SearchResultInterface